(function ($) {
    "use strict";
    
    const plyrVideo = new Plyr('.plyr-video'),
      plyrAudio = new Plyr('.plyr-audio'),
      plyrYoutube = new Plyr('.plyr-youtube'),
      plyrVimeo = new Plyr('.plyr-vimeo');
    
})(jQuery);